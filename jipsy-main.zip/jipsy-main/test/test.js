function hello() {
  let helloworld = "helloworld"
  console.log(helloworld)
}

console.log("Hi!")
hello()